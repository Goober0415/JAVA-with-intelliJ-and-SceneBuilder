//Ivonne Nelson inelson1@cnm.edu
//SnowFrame.java 

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;

public class SnowFrame extends JFrame{
	private final int MID = 150;
	private final int TOP = 50;
	private SnowPanel snowPanel;
	
	public SnowFrame(){
	
	snowPanel = new SnowPanel();
	snowPanel.setBackground(Color.cyan);	
	add(snowPanel);
	
		
	}

	class SnowPanel extends JPanel{
	
	    @Override
	    public void paintComponent(Graphics page){
		super.paintComponent(page);
		page.setColor(Color.blue);
		page.fillRect(0, 175, 300, 50);	//ground
		
		page.setColor(Color.yellow);
		page.fillOval(-20, -20, 80, 80);	//sun
	
		page.setColor(Color.white);
		page.fillOval(MID - 20, TOP, 40, 40);	//head
		page.fillOval(MID - 35, TOP + 35, 70, 50);	//upper torso
		page.fillOval(MID - 50, TOP + 80, 100, 60);	//lower torso
		
		page.setColor(Color.black);
		page.fillOval(MID - 10, TOP + 10, 5, 5);	//left eye
		page.fillOval(MID + 5, TOP + 10, 5, 5);		//right eye
		
		page.drawArc(MID - 10, TOP + 20, 20, 10, 190, 160);	//smile
		
		page.drawLine(MID - 25, TOP + 60, MID - 50, TOP + 40);	//left arm
		page.drawLine(MID + 25, TOP + 60, MID + 55, TOP + 60);	//right arm
		
		page.drawLine(MID - 20, TOP + 5, MID + 20, TOP + 5);//brim of hat
		page.fillRect(MID - 15, TOP - 20, 30, 25);	//top of hat
	   }
	}
	
	
	

}